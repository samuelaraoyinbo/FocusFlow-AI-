import React, { useState, useEffect } from 'react';
import { auth, db, collection, addDoc, query, where, orderBy, onSnapshot, deleteDoc, doc, Timestamp } from '../firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { generateSummary, generateAudio, summarizeAudio } from '../services/geminiService';
import { Summary, OperationType, FirestoreErrorInfo } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Loader2, Play, Trash2, FileText, Volume2, AlertCircle, Heart, Sparkles, Upload, Music, FileAudio, X, Copy, Check } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { cn } from '../lib/utils';

export function Home() {
  const [user] = useAuthState(auth);
  const [inputText, setInputText] = useState('');
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [summaries, setSummaries] = useState<Summary[]>([]);
  const [loading, setLoading] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) {
      setSummaries([]);
      return;
    }

    const q = query(
      collection(db, 'summaries'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Summary));
      setSummaries(docs);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'summaries');
    });

    return () => unsubscribe();
  }, [user]);

  const handleFirestoreError = (err: any, operationType: OperationType, path: string | null) => {
    const errInfo: FirestoreErrorInfo = {
      error: err instanceof Error ? err.message : String(err),
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
        emailVerified: auth.currentUser?.emailVerified,
        isAnonymous: auth.currentUser?.isAnonymous,
        tenantId: auth.currentUser?.tenantId,
        providerInfo: auth.currentUser?.providerData.map(provider => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL
        })) || []
      },
      operationType,
      path
    };
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    setError("Database error. Please try again later.");
  };

  const handleGenerate = async () => {
    if (!user) {
      setError("Please sign in to generate summaries.");
      return;
    }
    if (!inputText.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const summaryText = await generateSummary(inputText);

      await addDoc(collection(db, 'summaries'), {
        userId: user.uid,
        originalText: inputText,
        summaryText,
        createdAt: Timestamp.now(),
      });

      setInputText('');
      setLoading(false); // Reset immediately after success
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong.");
      setLoading(false); // Reset on error
    }
  };

  const handleAudioSummarize = async () => {
    if (!user) {
      setError("Please sign in to generate summaries.");
      return;
    }
    if (!audioFile) return;

    setLoading(true);
    setError(null);

    try {
      // Convert file to base64
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const base64 = (reader.result as string).split(',')[1];
          resolve(base64);
        };
        reader.onerror = reject;
      });
      reader.readAsDataURL(audioFile);
      const base64Audio = await base64Promise;

      const summaryText = await summarizeAudio(base64Audio, audioFile.type);

      await addDoc(collection(db, 'summaries'), {
        userId: user.uid,
        originalText: `Audio File: ${audioFile.name}`,
        summaryText,
        createdAt: Timestamp.now(),
      });

      setAudioFile(null);
      setLoading(false);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong with audio summarization.");
      setLoading(false);
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('audio/')) {
      setAudioFile(file);
      setError(null);
    } else if (file) {
      setError("Please upload a valid audio file (MP3, WAV, etc.)");
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'summaries', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `summaries/${id}`);
    }
  };

  const handleCopy = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error("Failed to copy text:", err);
    }
  };

  const playAudio = async (id: string, text: string) => {
    if (playingId) return;
    setPlayingId(id);
    try {
      const base64 = await generateAudio(text);
      const binary = atob(base64);
      const len = binary.length;
      const bytes = new Int16Array(len / 2);
      for (let i = 0; i < len; i += 2) {
        bytes[i / 2] = (binary.charCodeAt(i + 1) << 8) | binary.charCodeAt(i);
      }

      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const audioBuffer = audioContext.createBuffer(1, bytes.length, 24000);
      const channelData = audioBuffer.getChannelData(0);

      for (let i = 0; i < bytes.length; i++) {
        channelData[i] = bytes[i] / 32768;
      }

      const source = audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.onended = () => setPlayingId(null);
      source.connect(audioContext.destination);
      source.start();
    } catch (err) {
      console.error("Audio playback error:", err);
      setError("Failed to generate or play audio.");
      setPlayingId(null);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-6 py-12 sm:px-8 lg:py-20">
      <div className="mb-16 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 rounded-full bg-white/5 px-4 py-1.5 text-sm font-semibold text-white/60 ring-1 ring-white/10 mb-6"
        >
          <Sparkles className="h-4 w-4 text-white" />
          Powered by Gemini 1.5 Flash
        </motion.div>
        <h1 className="mb-6 text-5xl font-extrabold tracking-tight text-white sm:text-7xl">
          Focus<span className="text-white/40">Flow</span>
        </h1>
        <p className="mx-auto max-w-2xl text-lg leading-relaxed text-white/50 sm:text-xl">
          The minimal way to digest information. Paste your text and get instant text and audio summaries.
        </p>
        <div className="mt-10 flex justify-center">
          <a
            href="https://www.oncrowdr.com/explore/c/support-focus-flow-ai"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-[15px] bg-white/5 px-6 py-3 text-sm font-bold text-white transition-all hover:bg-white/10 active:scale-95 ring-1 ring-white/10"
          >
            <Heart className="h-4 w-4 fill-white" />
            Support FocusFlow
          </a>
        </div>
      </div>

      <div className="mb-16 rounded-[15px] bg-white/5 p-8 shadow-2xl ring-1 ring-white/10 backdrop-blur-sm">
        <div className="flex items-center gap-4 mb-8 border-b border-white/5 pb-4">
          <button 
            onClick={() => { setAudioFile(null); setInputText(''); }}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-bold transition-all",
              !audioFile ? "bg-white text-black" : "text-white/40 hover:text-white"
            )}
          >
            Text Input
          </button>
          <button 
            onClick={() => { setInputText(''); }}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-bold transition-all",
              audioFile ? "bg-white text-black" : "text-white/40 hover:text-white"
            )}
          >
            Audio Upload
          </button>
        </div>

        {!audioFile && inputText === '' && !loading && (
          <div className="flex flex-col gap-6">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste your content here..."
              className="min-h-[250px] w-full resize-none border-none bg-transparent text-xl leading-relaxed text-white placeholder-white/20 focus:ring-0"
            />
            <div className="flex items-center justify-center py-12 border-2 border-dashed border-white/10 rounded-[15px] hover:bg-white/[0.02] transition-all cursor-pointer group"
                 onClick={() => fileInputRef.current?.click()}>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={onFileChange} 
                accept="audio/*" 
                className="hidden" 
              />
              <div className="text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-white/5 text-white/40 group-hover:bg-white/10 group-hover:text-white transition-all">
                  <Upload className="h-8 w-8" />
                </div>
                <p className="text-lg font-bold text-white/60 group-hover:text-white">Or upload an audio file</p>
                <p className="text-sm text-white/20 mt-1">MP3, WAV, M4A up to 20MB</p>
              </div>
            </div>
          </div>
        )}

        {inputText !== '' && (
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Paste your content here..."
            className="min-h-[250px] w-full resize-none border-none bg-transparent text-xl leading-relaxed text-white placeholder-white/20 focus:ring-0"
          />
        )}

        {audioFile && (
          <div className="min-h-[250px] flex flex-col items-center justify-center">
            <div className="relative mb-6">
              <div className="flex h-24 w-24 items-center justify-center rounded-[25px] bg-white/10 text-white shadow-2xl ring-1 ring-white/20">
                <FileAudio className="h-12 w-12" />
              </div>
              <button 
                onClick={() => setAudioFile(null)}
                className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1.5 text-white shadow-lg hover:bg-red-600 transition-all"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <h3 className="text-xl font-bold text-white">{audioFile.name}</h3>
            <p className="mt-2 text-white/40">{(audioFile.size / (1024 * 1024)).toFixed(2)} MB • Ready to summarize</p>
          </div>
        )}

        <div className="mt-8 flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between border-t border-white/5 pt-8">
          <div className="flex items-center gap-3 text-sm font-medium text-white/30">
            <div className="h-2 w-2 rounded-full bg-white/20" />
            {audioFile ? (
              <span>Audio file detected</span>
            ) : (
              <span>{inputText.length.toLocaleString()} characters</span>
            )}
          </div>
          <button
            onClick={audioFile ? handleAudioSummarize : handleGenerate}
            disabled={loading || (!inputText.trim() && !audioFile)}
            className={cn(
              "flex items-center justify-center gap-3 rounded-[15px] bg-white px-8 py-4 text-lg font-bold text-black transition-all active:scale-95 disabled:opacity-20",
              !loading && "hover:bg-white/90 hover:shadow-[0_0_30px_rgba(255,255,255,0.1)]"
            )}
          >
            {loading ? (
              <>
                <Loader2 className="h-6 w-6 animate-spin" />
                <span>Generating...</span>
              </>
            ) : (
              <>
                {audioFile ? <Music className="h-5 w-5" /> : <Send className="h-5 w-5" />}
                <span>{audioFile ? 'Summarize Audio' : 'Generate'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 flex items-center gap-4 rounded-[15px] bg-red-500/10 p-5 text-red-400 ring-1 ring-red-500/20"
        >
          <AlertCircle className="h-6 w-6 shrink-0" />
          <p className="font-semibold">{error}</p>
        </motion.div>
      )}

      <div className="space-y-8">
        <h2 className="text-2xl font-bold text-white/90 px-2">Recent Summaries</h2>
        <AnimatePresence mode="popLayout">
          {summaries.map((summary) => (
            <motion.div
              key={summary.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="group relative rounded-[15px] bg-white/[0.03] p-8 ring-1 ring-white/5 transition-all hover:bg-white/[0.05] hover:ring-white/10"
            >
              <div className="mb-6 flex items-start justify-between">
                <div className="flex items-center gap-3 text-xs font-bold uppercase tracking-widest text-white/30">
                  <span className="rounded-md bg-white/5 px-2 py-1">Summary</span>
                  <span>{summary.createdAt?.toDate().toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(summary.id, summary.summaryText)}
                    className="rounded-xl p-2.5 text-white/20 transition-all hover:bg-white/10 hover:text-white group-hover:opacity-100"
                    title="Copy to clipboard"
                  >
                    {copiedId === summary.id ? (
                      <Check className="h-5 w-5 text-green-400" />
                    ) : (
                      <Copy className="h-5 w-5" />
                    )}
                  </button>
                  <button
                    onClick={() => handleDelete(summary.id)}
                    className="rounded-xl p-2.5 text-white/20 transition-all hover:bg-red-500/10 hover:text-red-400 group-hover:opacity-100"
                    title="Delete summary"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <div className="prose prose-invert max-w-none text-lg leading-relaxed text-white/80">
                <ReactMarkdown>{summary.summaryText}</ReactMarkdown>
              </div>

              <div className="mt-8 flex flex-wrap items-center gap-6 border-t border-white/5 pt-8">
                <button
                  onClick={() => playAudio(summary.id, summary.summaryText)}
                  disabled={playingId === summary.id}
                  className="flex items-center gap-3 rounded-[15px] bg-white px-6 py-3 text-sm font-bold text-black transition-all hover:bg-white/90 active:scale-95 disabled:opacity-50"
                >
                  {playingId === summary.id ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <Play className="h-5 w-5 fill-current" />
                  )}
                  {playingId === summary.id ? 'Generating Audio...' : 'Play Audio'}
                </button>
                <div className="flex items-center gap-2 text-white/40">
                  <Volume2 className="h-5 w-5" />
                  <span className="text-sm font-semibold">AI Voice Synthesis</span>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {!user && !loading && summaries.length === 0 && (
          <div className="py-20 text-center rounded-[15px] bg-white/[0.02] border border-dashed border-white/10">
            <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-[20px] bg-white/5 text-white/20">
              <LogIn className="h-10 w-10" />
            </div>
            <h3 className="text-xl font-bold text-white">Sign in to save history</h3>
            <p className="mt-2 text-white/40">Your summaries will be synced across all your devices.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function LogIn({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
      <polyline points="10 17 15 12 10 7" />
      <line x1="15" x2="3" y1="12" y2="12" />
    </svg>
  );
}
