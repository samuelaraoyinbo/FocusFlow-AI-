import React from 'react';
import { motion } from 'motion/react';
import { Heart, Shield, Zap, Coffee, ExternalLink } from 'lucide-react';

export function About() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-20 sm:px-8 lg:py-32">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="mx-auto mb-10 flex h-24 w-24 items-center justify-center rounded-[24px] bg-white text-black shadow-2xl shadow-white/10">
          <Zap className="h-12 w-12 fill-current" />
        </div>
        <h1 className="mb-8 text-5xl font-extrabold tracking-tight text-white sm:text-7xl">
          FocusFlow
        </h1>
        <p className="mx-auto mb-16 max-w-2xl text-xl leading-relaxed text-white/50">
          FocusFlow AI is a free AI tool for summaries. We believe that powerful technology should be accessible to everyone, helping you save time and focus on what truly matters.
        </p>

        <div className="grid gap-8 sm:grid-cols-2">
          <div className="rounded-[15px] bg-white/[0.03] p-10 ring-1 ring-white/10 backdrop-blur-sm text-left">
            <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-[12px] bg-white/5 text-white">
              <Shield className="h-7 w-7" />
            </div>
            <h3 className="mb-3 text-xl font-bold text-white">Privacy First</h3>
            <p className="text-lg text-white/40 leading-relaxed">Your data is yours. We process summaries securely and only store what you choose to save.</p>
          </div>
          <div className="rounded-[15px] bg-white/[0.03] p-10 ring-1 ring-white/10 backdrop-blur-sm text-left">
            <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-[12px] bg-white/5 text-white">
              <Heart className="h-7 w-7" />
            </div>
            <h3 className="mb-3 text-xl font-bold text-white">Community Driven</h3>
            <p className="text-lg text-white/40 leading-relaxed">Built for students, researchers, and professionals who need to digest information quickly.</p>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-20 rounded-[15px] bg-white p-12 text-black shadow-2xl"
        >
          <div className="mb-8 flex justify-center">
            <Coffee className="h-16 w-16" />
          </div>
          <h2 className="mb-6 text-3xl font-extrabold tracking-tight">Keep FocusFlow free for others</h2>
          <p className="mx-auto mb-10 max-w-xl text-lg font-medium text-black/60 leading-relaxed">
            Your support helps us cover server costs and keep this tool accessible to everyone worldwide. Every contribution makes a difference.
          </p>
          <a
            href="https://www.oncrowdr.com/explore/c/support-focus-flow-ai"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 rounded-[15px] bg-black px-10 py-5 text-xl font-bold text-white transition-all hover:scale-105 active:scale-95"
          >
            Support FocusFlow
            <ExternalLink className="h-6 w-6" />
          </a>
        </motion.div>
      </motion.div>
    </div>
  );
}
