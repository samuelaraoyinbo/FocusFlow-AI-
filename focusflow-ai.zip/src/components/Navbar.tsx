import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { auth, googleProvider, signInWithPopup, signOut } from '../firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { LogIn, LogOut, Info, Home, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

export function Navbar() {
  const [user] = useAuthState(auth);
  const location = useLocation();

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const navItems = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'About', path: '/about', icon: Info },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full bg-[#0A0A0A]/80 backdrop-blur-xl border-b border-white/5">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 sm:px-8">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="flex h-10 w-10 items-center justify-center rounded-[12px] bg-white text-black transition-transform group-hover:scale-105">
            <Sparkles className="h-6 w-6" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white">FocusFlow</span>
        </Link>

        <div className="flex items-center gap-8">
          <div className="flex items-center gap-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={cn(
                  "flex items-center gap-2 text-sm font-semibold transition-all hover:text-white",
                  location.pathname === item.path ? "text-white" : "text-white/50"
                )}
              >
                <item.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{item.name}</span>
              </Link>
            ))}
          </div>

          {user ? (
            <div className="flex items-center gap-4">
              <img
                src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`}
                alt={user.displayName || 'User'}
                className="h-9 w-9 rounded-full border border-white/10"
                referrerPolicy="no-referrer"
              />
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 rounded-[15px] bg-white/5 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white/10 active:scale-95"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden md:inline">Sign Out</span>
              </button>
            </div>
          ) : (
            <button
              onClick={handleLogin}
              className="flex items-center gap-2 rounded-[15px] bg-white px-6 py-2.5 text-sm font-bold text-black transition-all hover:bg-white/90 active:scale-95"
            >
              <LogIn className="h-4 w-4" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}
