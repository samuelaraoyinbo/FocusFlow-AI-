import { GoogleGenAI, Modality } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY as string;

export async function generateSummary(text: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey });
  const response = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: `Please provide a concise and clear summary of the following text:\n\n${text}`,
    config: {
      systemInstruction: "You are a helpful assistant that specializes in summarizing text for busy people. Keep it professional and easy to read.",
    },
  });
  return response.text || "Failed to generate summary.";
}

export async function generateAudio(text: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Say clearly: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("Failed to generate audio.");
  }
  return base64Audio;
}

export async function summarizeAudio(base64Audio: string, mimeType: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey });
  const response = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: [
      {
        inlineData: {
          data: base64Audio,
          mimeType: mimeType,
        },
      },
      {
        text: "Please provide a concise and clear summary of this audio file.",
      },
    ],
    config: {
      systemInstruction: "You are a helpful assistant that specializes in summarizing audio for busy people. Keep it professional and easy to read.",
    },
  });
  return response.text || "Failed to generate audio summary.";
}
