import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { About } from './pages/About';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#0A0A0A] font-sans text-white antialiased">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </main>
        <footer className="border-t border-white/5 bg-[#0A0A0A] py-12">
          <div className="mx-auto max-w-7xl px-6 text-center text-sm font-medium text-white/20 sm:px-8">
            <p>© {new Date().getFullYear()} FocusFlow. Built with Intelligence.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}
